<?php

namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class DefaultController
{
    /**
      * @Route("/")
      */
    public function homepage($name)
    {
        return new Response("Ovo je naslovna stranica.");
    }
}