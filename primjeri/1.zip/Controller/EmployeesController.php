<?php

namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class EmployeesController
{
    /**
      * @Route("/zaposlenici")
      */
    public function index($name)
    {
        return new Response("Ovdje ide popis zaposlenika");
    }
    
    /**
      * @Route("/zaposlenici/novi")
      */
    public function create()
    {
        return new Response("Ovdje ide forma za unos zaposlenika");
    }
    
    /**
      * @Route("/zaposlenici/uredivanje/{id}")
      */
    public function edit($id)
    {
        return new Response("Ovdje ide forma za uređivanje zaposlenika {$id}");
    }
}










