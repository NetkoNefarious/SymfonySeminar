<?php

namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ManagementController
{
    /**
      * @Route("/management/{id}")
      */
    public function index($id)
    {
        return new Response("Ovo je sučelje za dodjeljivanje projekata korisniku {$id}");
    }
}










