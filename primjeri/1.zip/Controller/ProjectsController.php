<?php

namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ProjectsController
{
    /**
      * @Route("/projekti")
      */
    public function index($name)
    {
        return new Response("Ovdje ide popis projekata");
    }
    
    /**
      * @Route("/projekti/novi")
      */
    public function create()
    {
        return new Response("Ovdje ide forma za unos projekta");
    }
    
    /**
      * @Route("/projekti/uredivanje/{id}")
      */
    public function edit($id)
    {
        return new Response("Ovdje ide forma za uređivanje projekta {$id}");
    }
}










