<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Intl\Exception\NotImplementedException;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/employees")
 */
class EmployeesController extends AbstractController
{
    /**
     * @Route("/", name="employees.index")
     */
    public function index()
    {
        return $this->render("employees/index.html.twig", [
            "employees" => [
                [
                    "id"        => 2,
                    "firstName" => "John",
                    "lastName"  => "Doe",
                    "email"     => "johndoe@acmeltd.com",
                ],
                [
                    "id"        => 1,
                    "firstName" => "Jane",
                    "lastName"  => "Doe",
                    "email"     => "janedoe@acmeltd.com",
                ],
            ]
        ]);
    }

    /**
     * @Route("/create/", name="employees.create")
     */
    public function create()
    {
        return $this->render("employees/create.html.twig");
    }

    /**
     * @Route("/edit/{id}", name="employees.edit")
     */
    public function edit($id)
    {
        return $this->render("employees/edit.html.twig");
    }

    /**
     * @Route("/delete/{id}", name="employees.delete")
     */
    public function delete()
    {
        throw new NotImplementedException("Not implemented");
    }
}