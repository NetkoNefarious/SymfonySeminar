<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Intl\Exception\NotImplementedException;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/management")
 */
class ManagementController extends AbstractController
{
    /**
     * @Route("/{employeeId}", name="management.index")
     */
    public function index($employeeId)
    {
        return $this->render("management/index.html.twig", [
            "employee" => [
                "id" => $employeeId,
                "firstName" => "John",
                "lastName" => "Doe",
            ],
            "assignedProjects" => [
                [
                    "id" => 3,
                    "name" => "Sample project #3",
                    "description" => "Description of the sample project #3",
                    "createdAt" => new \DateTime("2018-12-18"),
                ],
            ],
            "unassignedProjects" => [
                [
                    "id" => 2,
                    "name" => "Sample project #1",
                    "description" => "Description of the sample project #1",
                    "createdAt" => new \DateTime("2018-12-05"),
                ],
                [
                    "id" => 1,
                    "name" => "Sample project #1",
                    "description" => "Description of the sample project #1",
                    "createdAt" => new \DateTime("2018-11-27"),
                ],
            ]
        ]);
    }

    /**
     * @Route("/{employeeId}/assign/{projectId}", name="management.assign")
     */
    public function assign($employeeId, $projectId)
    {
        throw new NotImplementedException("Not implemented.");
    }

    /**
     * @Route("/{employeeId}/unassign/{projectId}", name="management.unassign")
     */
    public function unassign($employeeId, $projectId)
    {
        throw new NotImplementedException("Not implemented.");
    }
}