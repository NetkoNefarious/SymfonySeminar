<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Intl\Exception\NotImplementedException;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/projects")
 */
class ProjectsController extends AbstractController
{
    /**
     * @Route("/", name="projects.index")
     */
    public function index()
    {
        return $this->render("projects/index.html.twig", [
            "projects" => [
                [
                    "id" => 3,
                    "name" => "Sample project #3",
                    "description" => "Description of the sample project #3",
                    "createdAt" => new \DateTime("2018-12-18"),
                ],
                [
                    "id" => 2,
                    "name" => "Sample project #1",
                    "description" => "Description of the sample project #1",
                    "createdAt" => new \DateTime("2018-12-05"),
                ],
                [
                    "id" => 1,
                    "name" => "Sample project #1",
                    "description" => "Description of the sample project #1",
                    "createdAt" => new \DateTime("2018-11-27"),
                ],
            ],
        ]);
    }

    /**
     * @Route("/create/", name="projects.create")
     */
    public function create()
    {
        return $this->render("projects/create.html.twig");
    }

    /**
     * @Route("/edit/{id}", name="projects.edit")
     */
    public function edit($id)
    {
        return $this->render("projects/edit.html.twig");
    }

    /**
     * @Route("/delete/{id}", name="projects.delete")
     */
    public function delete()
    {
        throw new NotImplementedException("Not implemented");
    }
}